function uploadImages() {
  const input = document.getElementById("uploadInput");
  const preview = document.getElementById("imagePreview");

  if (input.files && input.files.length > 0) {
    preview.innerHTML = "";

    for (let i = 0; i < input.files.length; i++) {
      const reader = new FileReader();

      reader.onload = function (e) {
        const img = new Image();
        img.src = e.target.result;
        preview.appendChild(img);
      };

      reader.readAsDataURL(input.files[i]);
    }
  } else {
    alert("Please select at least one image.");
  }
}
