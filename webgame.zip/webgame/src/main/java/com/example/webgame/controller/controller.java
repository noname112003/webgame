package com.example.webgame.controller;


import com.example.webgame.model.Game;
import com.example.webgame.service.GameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.filter.HiddenHttpMethodFilter;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class controller {

    @Autowired
    GameService gameService;
    @GetMapping("/post")
    public ModelAndView Post(){

        ModelAndView modelAndView=new ModelAndView("client/postgame.html");
        modelAndView.addObject("game",new Game() );
        return modelAndView;
    }
    @PostMapping ("/viewgameclient")
    public ModelAndView viewgameclient(@RequestParam("id") Integer id){
        Game game=gameService.findById(Long.valueOf(id));

        ModelAndView modelAndView=new ModelAndView("client/viewgame.html");
        modelAndView.addObject("game", game);
        return modelAndView;
    }
    @PostMapping ("/viewgameuser")
    public ModelAndView viewgameuser(@RequestParam("id") Integer id){
        Game game=gameService.findById(Long.valueOf(id));

        ModelAndView modelAndView=new ModelAndView("user/viewgame.html");
        modelAndView.addObject("game", game);
        return modelAndView;
    }
    @GetMapping("/game")
    public ModelAndView Games(){
        //picture pic1=new picture(1L,"/assets/img/game/AM6.jpg");
        //picture pic2=new picture(2L,"/assets/img/game/AM6.jpg");
        //serviceGame.save(pic1);
        //serviceGame.save(pic2);
       List<Game> Games = gameService.findAll();
        ModelAndView modelAndView=new ModelAndView("user/index.html");
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @GetMapping("/gamemoi")
    public ModelAndView Gamemoi(){
        //picture pic1=new picture(1L,"/assets/img/game/AM6.jpg");
        //picture pic2=new picture(2L,"/assets/img/game/AM6.jpg");
        //serviceGame.save(pic1);
        //serviceGame.save(pic2);
        List<Game> Games = gameService.findAll();
        ModelAndView modelAndView=new ModelAndView("user/gamemoi.html");
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @GetMapping("/gamemoiclient")
    public ModelAndView Gamemoiclient(){
        //picture pic1=new picture(1L,"/assets/img/game/AM6.jpg");
        //picture pic2=new picture(2L,"/assets/img/game/AM6.jpg");
        //serviceGame.save(pic1);
        //serviceGame.save(pic2);
        List<Game> Games = gameService.findAll();
        ModelAndView modelAndView=new ModelAndView("client/gamemoi.html");
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @GetMapping("/gamekhuyenmai")
    public ModelAndView Gamekhuyenmai(){
        //picture pic1=new picture(1L,"/assets/img/game/AM6.jpg");
        //picture pic2=new picture(2L,"/assets/img/game/AM6.jpg");
        //serviceGame.save(pic1);
        //serviceGame.save(pic2);

        ModelAndView modelAndView=new ModelAndView("user/gamekhuyenmai.html");

        return modelAndView;
    }
    @GetMapping("/gamekhuyenmaiclient")
    public ModelAndView Gamekhuyenmaiclient(){
        //picture pic1=new picture(1L,"/assets/img/game/AM6.jpg");
        //picture pic2=new picture(2L,"/assets/img/game/AM6.jpg");
        //serviceGame.save(pic1);
        //serviceGame.save(pic2);

        ModelAndView modelAndView=new ModelAndView("client/gamekhuyenmai.html");

        return modelAndView;
    }
    @GetMapping("/quanlygame")
    public ModelAndView quanlygame(){
        List<Game> Games = gameService.findAll();
        ModelAndView modelAndView=new ModelAndView("client/quanlygame.html");
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @PostMapping("/quanlygame")
    public ModelAndView quanlygame1(@ModelAttribute("game")Game game){
        gameService.save(game);
        List<Game> Games = gameService.findAll();
        ModelAndView modelAndView=new ModelAndView("client/quanlygame.html");
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @PostMapping("/delete")
    public ModelAndView delete(@RequestParam("id") Integer id){
        //gameService.remove(game);
        gameService.remove(id);
        List<Game> Games = gameService.findAll();
        ModelAndView modelAndView=new ModelAndView("client/quanlygame.html");
        modelAndView.addObject("game", Games);
        return modelAndView;
    }

    @PostMapping("/game")
    public ModelAndView Save(@ModelAttribute("game")Game game){
        //picture pic1=new picture(1L,"/assets/img/game/AM6.jpg");
        //picture pic2=new picture(2L,"/assets/img/game/AM6.jpg");
        //serviceGame.save(pic1);
        //serviceGame.save(pic2);
        gameService.save(game);
        List<Game> Games = gameService.findAll();
        ModelAndView modelAndView=new ModelAndView("user/index.html");
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @GetMapping("/hanhdong")
    public ModelAndView hanhdong(){
        ModelAndView modelAndView=new ModelAndView("user/theloai.html");
        List<Game> Games = gameService.findByCategory("Hành động");
        String text="Hành động";
        modelAndView.addObject("text",text);
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @GetMapping("/hanhdongclient")
    public ModelAndView hanhdongclient(){
        ModelAndView modelAndView=new ModelAndView("client/theloai.html");
        List<Game> Games = gameService.findByCategory("Hành động");
        String text="Hành động";
        modelAndView.addObject("text",text);
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @GetMapping("/chienthuat")
    public ModelAndView chienthuat(){
        ModelAndView modelAndView=new ModelAndView("user/theloai.html");
        List<Game> Games = gameService.findByCategory("Chiến thuật");
        String text="Chiến thuật";
        modelAndView.addObject("text",text);
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @GetMapping("/chienthuatclient")
    public ModelAndView chienthuatclient(){
        ModelAndView modelAndView=new ModelAndView("client/theloai.html");
        List<Game> Games = gameService.findByCategory("Chiến thuật");
        String text="Chiến thuật";
        modelAndView.addObject("text",text);
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @GetMapping("/thegioimo")
    public ModelAndView thegioimo(){
        ModelAndView modelAndView=new ModelAndView("user/theloai.html");
        List<Game> Games = gameService.findByCategory("Thế giới mở");
        String text="Thế giới mở";
        modelAndView.addObject("text",text);
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @GetMapping("/thegioimoclient")
    public ModelAndView thegioimoclient(){
        ModelAndView modelAndView=new ModelAndView("client/theloai.html");
        List<Game> Games = gameService.findByCategory("Thế giới mở");
        String text="Thế giới mở";
        modelAndView.addObject("text",text);
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @GetMapping("/duaxe")
    public ModelAndView duaxe(){
        ModelAndView modelAndView=new ModelAndView("user/theloai.html");
        List<Game> Games = gameService.findByCategory("Đua xe");
        String text="Đua xe";
        modelAndView.addObject("text",text);
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @GetMapping("/duaxeclient")
    public ModelAndView duaxeclient(){
        ModelAndView modelAndView=new ModelAndView("client/theloai.html");
        List<Game> Games = gameService.findByCategory("Đua xe");
        String text="Đua xe";
        modelAndView.addObject("text",text);
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @GetMapping("/doikhang")
    public ModelAndView doikhang(){
        ModelAndView modelAndView=new ModelAndView("user/theloai.html");
        List<Game> Games = gameService.findByCategory("Đối kháng");
        String text="Đối kháng";
        modelAndView.addObject("text",text);
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @GetMapping("/doikhangclient")
    public ModelAndView doikhangclient(){
        ModelAndView modelAndView=new ModelAndView("client/theloai.html");
        List<Game> Games = gameService.findByCategory("Đối kháng");
        String text="Đối kháng";
        modelAndView.addObject("text",text);
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @GetMapping("/kinhdi")
    public ModelAndView kinhdi(){
        ModelAndView modelAndView=new ModelAndView("user/theloai.html");
        List<Game> Games = gameService.findByCategory("Kinh dị");
        String text="Kinh dị";
        modelAndView.addObject("text",text);
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @GetMapping("/kinhdiclient")
    public ModelAndView kinhdiclient(){
        ModelAndView modelAndView=new ModelAndView("client/theloai.html");
        List<Game> Games = gameService.findByCategory("Kinh dị");
        String text="Kinh dị";
        modelAndView.addObject("text",text);
        modelAndView.addObject("game", Games);
        return modelAndView;
    }
    @PostMapping("/find")
    public ModelAndView find(@RequestParam("searchquery") String searchquery){
        ModelAndView modelAndView=new ModelAndView("user/find.html");
        List<Game> Games = gameService.findByName(searchquery);

        modelAndView.addObject("game", Games);
        return modelAndView;

    }
    @PostMapping("/findclient")
    public ModelAndView findclient(@RequestParam("searchquery") String searchquery){
        ModelAndView modelAndView=new ModelAndView("client/find.html");
        List<Game> Games = gameService.findByName(searchquery);

        modelAndView.addObject("game", Games);
        return modelAndView;

    }






}




