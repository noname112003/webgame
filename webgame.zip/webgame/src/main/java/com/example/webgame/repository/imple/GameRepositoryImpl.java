package com.example.webgame.repository.imple;


import com.example.webgame.repository.GameRepository;
import com.example.webgame.model.Game;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
@Service
public class GameRepositoryImpl implements GameRepository {

    @PersistenceContext
    private EntityManager em;

    @Override
    public List<Game> findAll() {
        TypedQuery<Game> query = em.createQuery("select c from Game c", Game.class);
        return query.getResultList();
    }
    @Override
    public void remove(Integer id) {
        try {
            Game entity = em.find(Game.class, id);
            if (entity != null) {
                em.remove(entity);
                em.flush();
            }
        } catch (Exception e) {
            e.printStackTrace(); // In ra thông tin lỗi
        }
    }
    @Override
    public Game findById(Long id) {
        TypedQuery<Game> query = em.createQuery("select c from Game c where  c.id=:id", Game.class);
        query.setParameter("id", id);
        try {
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }
    @Override
    public List<Game> findByCategory(String category){
        TypedQuery<Game> query = em.createQuery("select c from Game c where  c.theloai=:category", Game.class);
        query.setParameter("category", category);

        return query.getResultList();

    }
    @Override
    public List<Game> findByName(String name) {
        TypedQuery<Game> query = em.createQuery("select c from Game c where  c.tengame=:name", Game.class);
        query.setParameter("name", name);
        return query.getResultList();
    }
    @Override
    public void save(Game Game) {
        if (Game.getId() != null) {
            em.merge(Game);
        } else {
            em.persist(Game);
        }
    }
}

