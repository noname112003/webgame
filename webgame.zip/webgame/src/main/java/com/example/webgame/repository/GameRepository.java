package com.example.webgame.repository;

import com.example.webgame.model.Game;

public interface GameRepository extends Repository<Game> {
}
