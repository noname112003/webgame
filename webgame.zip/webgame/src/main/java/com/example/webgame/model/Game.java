package com.example.webgame.model;


import jakarta.persistence.*;

@Entity
@Table(name="games")
public class Game {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column
    private String link;
    @Column
    private String linkposter;
    @Column
    private String tengame;
    @Column
    private String theloai;
    @Column(columnDefinition = "NVARCHAR(10000)")
    private String motachung;
    @Column(columnDefinition = "NVARCHAR(10000)")
    private String motagame;
    @Column
    private Long price;
    @Column
    private Integer namphathanh;
    @Column
    private String nhaphathanh;

    public Integer getNamphathanh() {
        return namphathanh;
    }

    public void setNamphathanh(Integer namphathanh) {
        this.namphathanh = namphathanh;
    }

    public String getNhaphathanh() {
        return nhaphathanh;
    }

    public void setNhaphathanh(String nhaphathanh) {
        this.nhaphathanh = nhaphathanh;
    }

    public Long getPrice() {
        return price;
    }

    public void setPrice(Long price) {
        this.price = price;
    }

    public  Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getMotachung() {
        return motachung;
    }

    public void setMotachung(String motachung) {
        this.motachung = motachung;
    }

    public String getMotagame() {
        return motagame;
    }

    public void setMotagame(String motagame) {
        this.motagame = motagame;
    }

    public Game(Long id, String link, String tengame, String theloai) {
        this.id = id;
        this.link = link;
        this.tengame = tengame;
        this.theloai = theloai;
    }

    public Game() {
    }

    public String getTengame() {
        return tengame;
    }

    public void setTengame(String tengame) {
        this.tengame = tengame;
    }

    public String getTheloai() {
        return theloai;
    }

    public void setTheloai(String theloai) {
        this.theloai = theloai;
    }

    public Game(Long id, String link) {
        this.id = id;
        this.link = link;
    }

    public String getLinkposter() {
        return linkposter;
    }

    public void setLinkposter(String linkposter) {
        this.linkposter = linkposter;
    }
}
