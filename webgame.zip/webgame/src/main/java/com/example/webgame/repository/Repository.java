package com.example.webgame.repository;
import com.example.webgame.model.Game;

import java.util.List;

public interface Repository <T> {
    List<T> findAll();

    T findById(Long id);
    List<Game> findByName(String name);
    List<T> findByCategory(String category);
    void save(T model);
    void remove(Integer id);


}
