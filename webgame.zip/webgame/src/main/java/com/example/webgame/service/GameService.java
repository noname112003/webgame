package com.example.webgame.service;



import com.example.webgame.model.Game;

import java.util.List;

public interface GameService {
    List<Game> findAll();

    Game findById(Long id);
    List<Game> findByName(String name);
    List<Game> findByCategory(String category);
    void save(Game Game);
    void remove(Integer id);


}
