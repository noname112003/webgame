package com.example.webgame.service.impl;

import com.example.webgame.model.Game;
import com.example.webgame.repository.Repository;
import com.example.webgame.service.GameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GameServiceImpl implements GameService {

    @Autowired
    private Repository repository;

    @Override
    public List<Game> findAll() {
        return repository.findAll();
    }
    @Override
    public List<Game> findByCategory(String category){ return  repository.findByCategory(category); }
    @Override
    public Game findById(Long id) {
        return (Game) repository.findById(id);
    }
    @Override
    public List<Game> findByName(String name){ return  repository.findByName(name);}
    @Override
    public void save(Game customer) {
        repository.save(customer);
    }
    @Override
    public void remove(Integer id) { repository.remove(id);}

}
