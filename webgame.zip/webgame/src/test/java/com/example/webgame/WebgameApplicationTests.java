package com.example.webgame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebgameApplicationTests {

	@Test
	void contextLoads() {
	}

}
